http://10.14.44.182:38090/venus/pm/api/user/login

传参数 
{
    "username":"lubie.zhao@inmobi.com",
    "password":"admin"
}

返回


{
    "code": 200,
    "data": {
        "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50TmFtZSI6Imx1YmllLnpoYW9AaW5tb2JpLmNvbSIsInVzZXJfbmFtZSI6Imx1YmllLnpoYW9AaW5tb2JpLmNvbSIsInJvbGVzIjpbeyJpZCI6NCwicm9sZU5hbWUiOiJST0xFX1ZFTlVTIiwidmFsaWQiOjEsInBlcm1pc3Npb25zIjpbeyJpZCI6NiwidXJpIjoiZ2V0UGxhY2VtZW50cyJ9XX0seyJpZCI6Miwicm9sZU5hbWUiOiJST0xFX1VTRVIiLCJ2YWxpZCI6MSwicGVybWlzc2lvbnMiOltdfV0sImFjY291bnRHdWlkIjoiZTg2Yjc1M2IwNDAwODg5OWRmNjA5YmRmMzE1MjMyMjAiLCJhdXRob3JpdGllcyI6WyJST0xFX1ZFTlVTIiwiZ2V0UGxhY2VtZW50cyIsIlJPTEVfVVNFUiJdLCJwYXJlbnRJZCI6MCwiY2xpZW50X2lkIjoiQURNU19TWVNURU0iLCJiYWxhbmNlIjowLjAwLCJzY29wZSI6WyJ1c2VyX2luZm8iXSwiaWQiOjQwLCJleHAiOjE1OTczMjg4MjUsImp0aSI6IjA4NmFiNjYyLTk1ZjgtNDk1Mi04YTMxLTAyZjI5NTIxYjY4ZCIsImVtYWlsIjoibHViaWUuemhhb0Bpbm1vYmkuY29tIiwidXNlcm5hbWUiOiJsdWJpZS56aGFvQGlubW9iaS5jb20iLCJzdGF0dXMiOjEsImNoaWxkIjpbXX0._H84AM-LNc-5JgBBBxDb-S9k4o1gEBupWdsJ4RboxBs",
        "token_type": "bearer",
        "expires_in": "43200",
        "scope": "user_info",
        "id": "40",
        "accountName": "lubie.zhao@inmobi.com",
        "email": "lubie.zhao@inmobi.com",
        "accountGuid": "e86b753b04008899df609bdf31523220",
        "status": 1,
        "parentId": 0,
        "roles": [
            {
                "id": 4,
                "roleName": "ROLE_VENUS",
                "valid": 1,
                "permissions": [
                    {
                        "id": 6,
                        "uri": "getPlacements"
                    }
                ]
            },
            {
                "id": 2,
                "roleName": "ROLE_USER",
                "valid": 1,
                "permissions": []
            }
        ],
        "child": []
    },
    "msg": "success"
}