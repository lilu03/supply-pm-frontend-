import Cookies from 'js-cookie'

const TokenKey = 'token'
const TokenType = 'token_type'
export function getToken() {
  return Cookies.get(TokenKey)
}

export function setToken(token) {
  return Cookies.set(TokenKey, token)
}

export function removeToken() {
  return Cookies.remove(TokenKey)
}

export function getTokenType() {
  return Cookies.get(TokenType)
}
export function setTokenType(token) {
  return Cookies.set(TokenType, token)
}

export function removeTokenType() {
  return Cookies.remove(TokenType)
}