import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'             the icon show in the sidebar
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },
  {
    path: '/404',
    component: () => import('@/views/404'),
    hidden: true
  },
  {
    path: '/',
    component: Layout,
    redirect: '/home',
    children: [
      {
        path: '/home',
        meta: { title: '账号设置', icon: 'home' },
        component: () => import('@/views/home/index'),
        name: 'Home'
      },
      {
        path: 'home/edit2',
        hidden: true,
        meta: {
          activeMenu: '/home'
        },
        component: () => import('@/views/home/edit/index')
      }
    ]
  },
  {
    path: '/useSetting',
    component: Layout,
    redirect: '/useSetting',
    children: [
      {
        path: '/useSetting',
        meta: { title: '应用设置', icon: 'rate' },
        component: () => import('@/views/useSetting/index'),
        name: 'UseSetting'
      },
      {
        path: '/useSetting/edit2',
        hidden: true,
        alwaysShow: true,
        meta: {
          activeMenu: '/useSetting'
        },
        component: () => import('@/views/useSetting/edit/index')
      }
    ]
  },
  {
    path: '/advertising',
    component: Layout,
    redirect: '/advertising',
    children: [
      {
        path: '/advertising',
        meta: { title: '广告位设置', icon: 'rate' },
        component: () => import('@/views/advertising/index'),
        name: 'Advertising'
      },
      {
        path: '/advertising/edit2',
        hidden: true,
        alwaysShow: true,
        meta: {
          activeMenu: '/advertising'
        },
        component: () => import('@/views/advertising/edit/index')
      }
    ]
  },
  {
    path: '/advertisingRoot',
    component: Layout,
    redirect: '/advertisingRoot',
    children: [{
      path: '/advertisingRoot',
      meta: { title: '广告源设置', icon: 'rate' },
      component: () => import('@/views/advertisingRoot/index'),
      name: 'advertisingRoot'
    }]
  },
  {
    path: '/operation',
    component: Layout,
    redirect: '/operation',
    children: [{
      path: '/operation',
      meta: { title: '操作记录', icon: 'rate' },
      component: () => import('@/views/operation/index'),
      name: 'operation'
    }]
  },
  {
    path: '/check',
    component: Layout,
    redirect: '/check',
    children: [
      {
        path: '/check',
        meta: { title: '审核', icon: 'rate' },
        component: () => import('@/views/check/index'),
        name: 'Check'
      },
      {
        path: '/check/accountLIst',
        hidden: true,
        alwaysShow: true,
        meta: {
          activeMenu: '/check'
        },
        component: () => import('@/views/check/accountLIst/index')
      },
      {
        path: '/check/advertisingList',
        hidden: true,
        alwaysShow: true,
        meta: {
          activeMenu: '/check'
        },
        component: () => import('@/views/check/advertisingList/index')
      },
      {
        path: '/check/accountEdit',
        hidden: true,
        alwaysShow: true,
        meta: {
          activeMenu: '/check'
        },
        component: () => import('@/views/check/accountEdit/index')
      },
      {
        path: '/check/advertisingEdit',
        hidden: true,
        alwaysShow: true,
        meta: {
          activeMenu: '/check'
        },
        component: () => import('@/views/check/advertisingEdit/index')
      }
    ]
  },
  { path: '*', redirect: '/404', hidden: true }
]

const createRouter = () => new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
