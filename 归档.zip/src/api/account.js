import request from '@/utils/request'

// 账号列表查询
export function getPubList(params) {
  return request({
    url: '/venus/pm/pub/getPubList',
    method: 'post',
    data: params
  })
}

// 查询账户详情
export function getPubDetailInfo(params) {
  return request({
    url: '/venus/pm/pub/getPubDetailInfo',
    method: 'get',
    params
  })
}

// 账户注销
export function cancelPubAccount(params) {
  return request({
    url: '/venus/pm/pub/cancelPubAccount',
    method: 'get',
    params
  })
}

// 账户信息修改
export function editPubDetailInfo(params) {
  return request({
    url: '/venus/pm/pub/editPubDetailInfo',
    method: 'post',
    params
  })
}
