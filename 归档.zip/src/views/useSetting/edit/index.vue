<template>
  <div>
    <el-row>
      <el-col :span="24" style="padding: 10px 10px;">
        <h3>基本信息</h3>
      </el-col>
      <el-col :span="24" style="padding: 2px 10px;">
        <p class="text-a">App ID：163547aaeinge</p>
      </el-col>
      <el-col :span="24" style="padding: 2px 10px;">
        <p class="text-b">应用名称：航班1</p>
      </el-col>
      <el-col :span="24" style="padding: 2px 10px;">
        <p class="text-d">Bundle ID：test.inmob</p>
      </el-col>
      <el-col :span="24" style="padding: 2px 10px;">
        <p class="text-b">App URL：http://www.t</p>
      </el-col>
      <el-col :span="24" style="padding: 2px 10px;">
        <p class="text-b">操作系统：Android</p>
      </el-col>
      <el-col :span="24" style="padding: 2px 10px;">
        <p class="text-c">状态：正式</p>
      </el-col>
      <el-col :span="24" style="padding: 2px 10px;">
        <p class="text-c">行业：办公-电子文档</p>
      </el-col>
    </el-row>

    <el-row>
      <el-col :span="24" style="border:1px solid #D8DCE6; margin: 50px 20px 20px 20px;"></el-col>
    </el-row>

    <el-row>
      <el-col :span="24" style="padding: 10px 10px;">
        <h3>广告源设置</h3>
      </el-col>
      <el-col :span="24" style="padding: 2px 10px; position: relative;">
        <span class="text-b">账号名称：</span>
        <el-checkbox-group v-model="checkList" style="position: absolute; left: 220px; top:0;">
          <el-checkbox label="Ferf"></el-checkbox>
          <el-checkbox label="Brand"></el-checkbox>
          <el-checkbox label="RTB"></el-checkbox>
          <el-checkbox label="Rem"></el-checkbox>
        </el-checkbox-group>
      </el-col>
    </el-row>

    <el-row>
      <el-col :span="24" style="border:1px solid #D8DCE6; margin: 50px 20px 20px 20px;"></el-col>
    </el-row>

    <el-row>
      <el-col :span="24" style="padding: 10px 10px;">
        <h3>回收账号</h3>
      </el-col>
      <el-col :span="24" style="padding: 20px 10px;">
        <span class="text-e">账号回收：</span>
        <el-radio v-model="numRecycle" label="1">是</el-radio>
        <el-radio v-model="numRecycle" label="2">否</el-radio>
      </el-col>
      <el-col :span="24" style="padding:40px 205px;">
        <el-button size="small" class="btn">取消</el-button>
        <el-button type="primary" size="small" class="btn">保存</el-button>
      </el-col>
    </el-row>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        checkList: ['Ferf','Brand','RTB','Rem'],
        numRecycle:'1'
      }
    },
    watch: {},
    created() {
    },
    methods: {}
  }
</script>
<style scoped>
  h3 {
    color: #111111;
    margin-left: 30px;
  }

  .text-a {
    padding-left: 140px;
    font-size: 16px;
    color: #333333;
  }

  .text-b {
    padding-left: 125px;
    font-size: 16px;
    color: #333333;
  }

  .text-c {
    padding-left: 158px;
    font-size: 16px;
    color: #333333;
  }

  .text-d {
    padding-left: 118px;
    font-size: 16px;
    color: #333333;
  }

  .text-e {
    padding-top: 10px;
    padding-left: 125px;
    font-size: 16px;
    color: #333333;
  }

  .btn{ width: 110px; }
</style>
