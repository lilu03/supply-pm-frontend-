<template>
  <div>
    <el-row>
      <el-col :span="24" style="padding: 10px 10px;">
        <h3>基本信息</h3>
      </el-col>
      <el-col :span="24" style="padding: 2px 10px;">
        <p class="text-a">账号ID：{{info.pubId}}</p>
      </el-col>
      <el-col :span="24" style="padding: 2px 10px;">
        <p class="text-b">账号名称：<span class="text-c">{{info.accountName}}</span></p>
      </el-col>
      <el-col :span="24" style="padding: 2px 10px;">
        <p class="text-d">邮箱：{{info.registerEmail}}</p>
      </el-col>
      <el-col :span="24" style="padding: 2px 10px;">
        <p class="text-b">联系邮箱：<span class="text-c">{{info.contactEmail}}</span></p>
      </el-col>
      <el-col :span="24" style="padding: 2px 10px;">
        <p class="text-b">账号状态：{{info.auditStatus}}</p>
      </el-col>
      <el-col :span="24" style="padding: 20px 10px;">
        <span class="text-e">托管模式：</span>
        <el-radio v-model="info.managedMode" label="1">Self Serve</el-radio>
        <el-radio v-model="info.managedMode" label="2">Manager Serve</el-radio>
      </el-col>
    </el-row>

    <el-row>
      <el-col :span="24" style="border:1px solid #D8DCE6; margin: 50px 20px 20px 20px;"></el-col>
    </el-row>

    <el-row>
      <el-col :span="24" style="padding: 10px 10px;">
        <h3>广告源设置</h3>
      </el-col>
      <el-col :span="24" style="padding: 2px 10px; position: relative;">
        <span class="text-b">账号名称：</span>
        <el-checkbox-group v-model="checkListValue" class="groupSetting">
          <el-checkbox v-for="(item,index) in checkList" :label="item" :key="index">{{item}}</el-checkbox>
        </el-checkbox-group>
      </el-col>
    </el-row>

    <el-row>
      <el-col :span="24" style="border:1px solid #D8DCE6; margin: 50px 20px 20px 20px;"></el-col>
    </el-row>

    <el-row>
      <el-col :span="24" style="padding: 10px 10px;">
        <h3>回收账号</h3>
      </el-col>

      <el-col :span="24" style="padding: 20px 10px;">
        <span class="text-e">账号回收：</span>
        <el-radio-group @change="changeHandler" v-model="info.numRecycle">
          <el-radio class="radio" :label="1">是</el-radio>
          <el-radio class="radio" :label="0">否</el-radio>
        </el-radio-group>
      </el-col>

      <el-col :span="24" style="padding:40px 205px;">
        <el-button size="small" class="btn" @click="CancelConfiguration">取消</el-button>
        <el-button type="primary" size="small" class="btn" @click="saveConfiguration">保存</el-button>
      </el-col>
    </el-row>

    <el-dialog :visible.sync="dialogVisible" width="30%" :close-on-click-modal='false' :showClose="false">
      <h2>请确认测账号要回收！</h2>
      <span slot="footer" class="dialog-footer">
        <el-button @click="cancelAccountRecycle">取 消</el-button>
        <el-button type="primary" @click="affirmRecycleAccount">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
  import { getPubDetailInfo, cancelPubAccount, editPubDetailInfo } from '@/api/account'

  export default {
    data() {
      return {
        info: {
          accountName: '',
          auditStatus: '',
          contactEmail: '',
          managedMode: '',
          pubId: '',
          registerEmail: '',
          status: '',
          numRecycle: 0
        },

        checkList: [],

        checkListValue: [],

        text: '',

        dialogVisible: false
      }
    },
    watch: {},
    created() {
      this.getInfo()
    },
    methods: {
      // @Event api 获取账号详情
      getInfo() {
        getPubDetailInfo({ pubId: this.$route.query.id }).then(res => {
          if (res.code === 200) {
            this.info = res.data
            let result = res.data.dataSource
            this.checkList = result.split(',')
          }
        })
      },

      // @Change 账号回收弹框
      changeHandler(value) {
        if (value === 1) {
          this.dialogVisible = true
        }
      },

      // @Event api 确认回收账号
      affirmRecycleAccount() {
        cancelPubAccount({ pubId: this.$route.query.id }).then(res => {
          if (res.code === 200) {
            this.dialogVisible = false
            this.info.numRecycle = 1
            this.$message({ message: res.msg, type: 'success' })
          } else {
            this.dialogVisible = false
            this.info.numRecycle = 0
            this.$message.error({ message: res.msg })
          }
        }).catch(err => {
          this.dialogVisible = false
          this.info.numRecycle = 0
          this.$message.error({ message: '回收失败' })
        })
      },

      // @Event 取消账号回收
      cancelAccountRecycle() {
        this.dialogVisible = false
        this.info.numRecycle = 0
      },

      // @Event 取消配置页面
      CancelConfiguration() {
        this.$router.push({ path: '/' })
      },

      // @Event 保存配置页面
      saveConfiguration() {
        var values = []

        for (var key in this.checkListValue) {
          values.push(this.checkListValue[key])
        }

        let text = values.toString()
        console.log({
          pubId: this.$route.query.id,
          managedMode: this.info.managedMode,
          dataSource: text
        })
        editPubDetailInfo({
          pubId: this.$route.query.id,
          managedMode: this.info.managedMode,
          dataSource: text
        }).then(res => {
          if (res.code === 200) {
            this.$message({ message: res.msg, type: 'success' })
            this.$router.push({ path: '/' })
          }
        })
      }
    }
  }
</script>
<style scoped>
  h3 {
    color: #111111;
    margin-left: 30px;
  }

  .text-a {
    padding-left: 140px;
    font-size: 16px;
    color: #333333;
  }

  .text-b {
    padding-left: 125px;
    font-size: 16px;
    color: #333333;
  }

  .text-c {
    font-size: 16px;
    color: #1F67F3;
  }

  .text-d {
    padding-left: 157px;
    font-size: 16px;
    color: #333333;
  }

  .text-e {
    padding-top: 10px;
    padding-left: 125px;
    font-size: 16px;
    color: #333333;
  }

  .btn {
    width: 110px;
  }

  .groupSetting {
    position: absolute;
    left: 220px;
    top: 0;
  }
</style>
