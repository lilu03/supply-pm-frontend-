<template>
  <div>
    <el-row style="overflow: hidden;">
      <el-col :span="24" style="padding: 10px 10px;">
        <h3>财务信息：</h3>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">对公银行名称：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">对公开省市：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">对公开户支行：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">对公银行支行：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">对公银行账号：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">发票类型：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">发票内容：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">发票内容：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-row>
        <el-col :span="24" style="border:1px solid #D8DCE6; margin: 50px 20px 20px 20px;"></el-col>
      </el-row>

      <el-col :span="24" style="padding: 10px 10px;">
        <h3>企业信息：</h3>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">公司名称：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">统一信用代码：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">法定代表人姓名：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">主营应用所属行业：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">主营应用举例：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">注册地址：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">营业执照：</span><img src="" alt="" class="img">
      </el-col>

      <el-row>
        <el-col :span="24" style="border:1px solid #D8DCE6; margin: 50px 20px 20px 20px;"></el-col>
      </el-row>

      <el-col :span="24" style="padding: 10px 10px;">
        <h3>账号管理人信息：</h3>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">账号管理人姓名：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">账号管理人员身份证号：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">账号管理人员身手机号：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">营业执照：</span><img src="" alt="" class="img"><img src="" alt="" class="imgAga">
      </el-col>

      <el-row>
        <el-col :span="24" style="border:1px solid #D8DCE6; margin: 50px 20px 20px 20px;"></el-col>
      </el-row>
    </el-row>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        checkList: ['Ferf','Brand','RTB','Rem'],
        numRecycle:'1'
      }
    },
    watch: {},
    created() {
    },
    methods: {}
  }
</script>
<style scoped>
  h3 {
    color: #111111;
    margin-left: 30px;
  }

  .text-a {
    float: left;
    width: 200px;
    height: 30px;
    padding-left: 20px;
    margin-left: 100px;
    line-height: 30px;
    text-align: right;
    display: block;
    font-size: 16px;
    color: #333333;
  }

  .text-b{
    float: left;
    width: 300px;
    height: 30px;
    padding-left: 5px;
    line-height: 30px;
    text-align: left;
    display: block;
    font-size: 16px;
    color: #333333;
  }

  .img{
    float: left;
    width: 120px;
    height: 120px;
    border:1px solid #5a5e66;
  }

  .imgAga{
    float: left;
    width: 120px;
    height: 120px;
    border:1px solid #5a5e66;
    margin-left: 20px;
  }
</style>
