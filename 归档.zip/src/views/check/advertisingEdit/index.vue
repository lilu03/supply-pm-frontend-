<template>
  <div>
    <el-row style="overflow: hidden;">
      <el-col :span="24" style="padding: 10px 10px;">
        <h3>账户信息：</h3>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">账户ID：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">账户名称：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-row>
        <el-col :span="24" style="border:1px solid #D8DCE6; margin: 50px 20px 20px 20px;"></el-col>
      </el-row>

      <el-col :span="24" style="padding: 10px 10px;">
        <h3>应用信息：</h3>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">对公开户支行：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-col :span="24" style="padding: 10px 10px;">
        <span class="text-a">应用名称：</span><span class="text-b">163547aaeinge</span>
      </el-col>

      <el-row>
        <el-col :span="24" style="border:1px solid #D8DCE6; margin: 50px 20px 20px 20px;"></el-col>
      </el-row>

      <el-col :span="24" style="padding: 10px 10px;">
        <h3>企业信息：</h3>
      </el-col>

    </el-row>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        checkList: ['Ferf','Brand','RTB','Rem'],
        numRecycle:'1'
      }
    },
    watch: {},
    created() {
    },
    methods: {}
  }
</script>
<style scoped>
  h3 {
    color: #111111;
    margin-left: 30px;
  }

  .text-a {
    float: left;
    width: 200px;
    height: 30px;
    padding-left: 20px;
    margin-left: 100px;
    line-height: 30px;
    text-align: right;
    display: block;
    font-size: 16px;
    color: #333333;
  }

  .text-b{
    float: left;
    width: 300px;
    height: 30px;
    padding-left: 5px;
    line-height: 30px;
    text-align: left;
    display: block;
    font-size: 16px;
    color: #333333;
  }

  .img{
    float: left;
    width: 120px;
    height: 120px;
    border:1px solid #5a5e66;
  }

  .imgAga{
    float: left;
    width: 120px;
    height: 120px;
    border:1px solid #5a5e66;
    margin-left: 20px;
  }
</style>
