<template>
  <div class="app-container">
    <div class="filter-container">
      <div class="filter-add">
        <el-input v-model="userId" class="filter-input"></el-input>
        <el-button class="filter-item" type="primary">搜 索</el-button>
      </div>
      <div class="text">
        <span>账号：</span>
        <span>163547aaeingeyi</span>
      </div>
      <div class="account">
        <span>账号名称：</span>
        <span class="text-wps">163547aaeingeyi</span>
      </div>
      <div class="account">
        <span style="float: left;">广告源设置：</span>

        <el-checkbox v-model="checked1" class="ferf-check">Ferf</el-checkbox>

        <el-checkbox v-model="checked2" class="ferf-check">Brand</el-checkbox>

        <el-tree
          class="tree-text"
          :data="treeData"
          show-checkbox
          node-key="id"
          :default-expand-all="false"
          :default-expanded-keys="[2, 3]"
          :default-checked-keys="[]"
          :props="defaultProps">
        </el-tree>

        <el-checkbox v-model="checked3" class="ferf-check">Rem</el-checkbox>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    'data'() {
      return {
        'userId': '',
        'checked1': false,
        'checked2': false,
        'checked3': false,
        'treeData': [
          {
            'id': 1,
            'label': 'Brand',
            children: [{
              'id': 1 - 1,
              label: '二级-1'
            }, {
              'id': 1 - 2,
              label: '二级-2'
            }, {
              'id': 1 - 3,
              label: '二级-3'
            }]
          }
        ],
        'defaultProps': {
          'children': 'children',
          'label': 'label'
        }
      }
    },
    'created'() {
    },
    'methods': {
      'handlePlacementFilter'() {
      },
      'fetchData'() {
      },
      'handleCreateApp'() {
        this.$router.push({
          'path': '/views/home/accountLIst'
        })
      }
    },
    'computed': {}
  }
</script>
<style scoped lang="scss">
  .filter-container {
    overflow: hidden;
  }

  label {
    font-weight: 400;
  }

  .pagination {
    float: right;
    padding: 0;
    margin: 0;
  }

  .table {
    width: 100%;
    margin-top: 30px;
    margin-bottom: 30px;
  }

  .filter-item {
    width: 100px;
    height: 36px;
    margin-left: 15px;
  }

  .filter-input {
    width: 260px;
  }

  .account {
    overflow: hidden;
    padding: 15px 15px;
  }

  .text {
    padding: 15px 15px;
  }

  .text span {
    color: #333333;
    font-size: 16px;
  }

  .account span {
    color: #333333;
    font-size: 16px;
  }

  .account .text-wps {
    color: #1F67F3;
  }

  .tree-text {
    float: left;
    min-width: 130px;
    margin-top: -4px;
  }

  .ferf-check {
    float: left;
  }
</style>

