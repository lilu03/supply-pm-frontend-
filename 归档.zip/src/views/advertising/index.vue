<template>
  <div class="app-container">
    <div class="filter-container">
      <div class="filter-add">
        <el-input v-model="userId" placeholder="请输入账号ID搜索" suffix-icon="el-input__icon el-icon-search" class="filter-input"></el-input>

        <el-button class="filter-item" type="primary">搜 索</el-button>
      </div>
    </div>
    <el-table
      v-loading="listLoading"
      :data="list"
      class="table"
      element-loading-text="加载中"
      style="margin-top: 20px;"
      highlight-current-row
    >
      <el-table-column align="left" prop="report_date" label="广告位名称">
        <template slot-scope="scope">{{ scope.row.advertisingName }}</template>
      </el-table-column>
      <el-table-column align="center" prop="app_id" label="广告位ID">
        <template slot-scope="scope">{{ scope.row.advertisingId }}</template>
      </el-table-column>
      <el-table-column align="center" prop="os" label="设置">
        <template slot-scope="scope">
          <el-button @click="handleCreateApp" type="text" size="small">{{ scope.row.setting }} </el-button>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="os" label="状态">
        <template slot-scope="scope">{{ scope.row.state }}</template>
      </el-table-column>
      <el-table-column align="center" prop="os" label="审核">
        <template slot-scope="scope">{{ scope.row.audit }}</template>
      </el-table-column>
      <el-table-column align="center" prop="os" label="记录">
        <template slot-scope="scope">
          <el-button @click="" type="text" size="small">{{ scope.row.record1 }} </el-button>
        </template>
      </el-table-column>
      <el-table-column align="right" prop="os" label="记录">
        <el-button type="text" icon="el-icon-star-on" size="medium"></el-button>
      </el-table-column>
    </el-table>
    <pagination
      class="pagination"
      :total="total"
      :page.sync="queryFormat.pageNo"
      :limit.sync="queryFormat.pageSize"
      @pagination="fetchData"
    />
  </div>
</template>

<script>
  import Pagination from '@/components/Pagination'

  export default {
    components: { Pagination },
    data() {
      return {
        pagerCount: 5,
        queryFormat: {
          pageSize: 10,
          pageNo: 1,
          total: 0
        },
        listLoading: false,
        list: [{
          advertisingName: '广告位名称',
          advertisingId: '广告位Id',
          setting: '设置',
          state: '状态',
          audit: '审核',
          record1: '记录',
          record2: '记录'
        }],
        userId: '',
        total: 4
      }
    },
    created() {
    },
    methods: {
      handlePlacementFilter() {
      },
      fetchData() {
      },
      handleCreateApp() {
        this.$router.push({
          path: '/advertising/edit2'
        })
      }
    },
    computed: {}
  }
</script>
<style scoped lang="scss">
  .filter-container {
    overflow: hidden;
  }

  label {
    font-weight: 400;
  }

  .pagination {
    float: right;
    padding: 0;
    margin: 0;
  }

  .table {
    width: 100%;
    margin-top: 30px;
    margin-bottom: 30px;
  }

  .filter-item {
    width: 100px;
    height: 36px;
    margin-left: 15px;
  }

  .filter-input {
    width: 260px;
  }
</style>

