<template>
  <div>
    <el-form ref="form" :model="formData" label-width="240px">
      <el-col :span="24" style="padding: 10px 10px;">
        <h3>常规设置</h3>
      </el-col>

      <el-form-item label="静态广告：">
        <el-checkbox-group v-model="formData.type1">
          <el-checkbox label="Wi-Fi" name="type"></el-checkbox>
          <el-checkbox label="non-Wi-Fi" name="type"></el-checkbox>
        </el-checkbox-group>
      </el-form-item>

      <el-form-item label="视频广告：">
        <el-checkbox-group v-model="formData.type2">
          <el-checkbox label="Wi-Fi" name="type"></el-checkbox>
          <el-checkbox label="non-Wi-Fi" name="type"></el-checkbox>
        </el-checkbox-group>
      </el-form-item>

      <el-form-item label="ATS：">
        <el-radio-group v-model="formData.resource">
          <el-radio label="All"></el-radio>
          <el-radio label="HTTPS"></el-radio>
          <el-radio label="HPPT"></el-radio>
        </el-radio-group>
      </el-form-item>

      <el-form-item label="视频时长：">
        <el-select v-model="formData.videoDuration" placeholder="请选择活动区域">
          <el-option label="60" value="1"></el-option>
          <el-option label="45" value="2"></el-option>
          <el-option label="30" value="3"></el-option>
          <el-option label="15" value="4"></el-option>
          <el-option label="10" value="5"></el-option>
        </el-select>
        <span class="text-f">s</span>
      </el-form-item>

      <el-form-item label="视频声音：">
        <el-switch v-model="formData.videoVoice" active-text="on" inactive-text="off"></el-switch>
      </el-form-item>

      <el-form-item label="可跳过时延：">
        <el-select v-model="formData.skipDelayed" placeholder="请选择活动区域">
          <el-option label="5" value="1"></el-option>
          <el-option label="10" value="2"></el-option>
          <el-option label="15" value="3"></el-option>
        </el-select>
        <span class="text-f">s</span>
      </el-form-item>

      <el-row>
        <el-col :span="24" style="border:1px solid #D8DCE6; margin: 50px 20px 20px 20px;"></el-col>
      </el-row>

      <el-col :span="24" style="padding: 10px 10px;">
        <h3>价格设置</h3>
      </el-col>

      <el-form-item label="PE：">
        <el-input v-model="formData.pe" class="pe"></el-input>
        <span class="text-f">元</span>
      </el-form-item>

      <el-form-item label="Share Type：">
        <el-radio-group v-model="formData.type">
          <el-radio label="Autopilot"></el-radio>
          <el-radio label="Fix Revenue Share"></el-radio>
          <el-radio label="Max Revenue Share"></el-radio>
        </el-radio-group>
      </el-form-item>

      <el-form-item label="Brand Rev Share：">
        <el-input v-model="formData.brand_value" class="pe"></el-input>
        <span class="text-f"><95</span>
      </el-form-item>

      <el-form-item label="Perf Rev Share：">
        <el-input v-model="formData.Perf_value" class="pe"></el-input>
      </el-form-item>

      <el-form-item label="Rem Rev Share：">
        <el-input v-model="formData.Rem_value" class="pe"></el-input>
      </el-form-item>

      <el-row>
        <el-col :span="24" style="border:1px solid #D8DCE6; margin: 50px 20px 20px 20px;"></el-col>
      </el-row>

      <el-col :span="24" style="padding: 10px 10px;">
        <h3>广告源设置</h3>
      </el-col>

      <el-form-item label="广告源设置：">
        <el-checkbox-group v-model="formData.setting">
          <el-checkbox label="Ferf" name="type"></el-checkbox>
          <el-checkbox label="Brand" name="type"></el-checkbox>
          <el-checkbox label="RTB" name="type"></el-checkbox>
          <el-checkbox label="Rem" name="type"></el-checkbox>
        </el-checkbox-group>
      </el-form-item>

      <el-row>
        <el-col :span="24" style="border:1px solid #D8DCE6; margin: 50px 20px 20px 20px;"></el-col>
      </el-row>

      <el-col :span="24" style="padding: 10px 10px;">
        <h3>广告主黑/白名单设置</h3>
      </el-col>

      <el-form-item label="广告主黑/白名单设置：">
        <el-radio-group v-model="formData.black_white">
          <el-radio label="白名单设置"></el-radio>
          <el-radio label="黑名单设置"></el-radio>
        </el-radio-group>
      </el-form-item>

      <el-form-item>
        <el-upload
          class="upload-demo"
          action=""
          :on-preview="handlePreview"
          :on-remove="handleRemove"
          :before-remove="beforeRemove"
          multiple
          :limit="1"
          :on-exceed="handleExceed"
          :file-list="fileList">
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>

        <el-button type="primary" class="download" size="small">下载示例文件</el-button>
      </el-form-item>

      <el-form-item>
        <el-input type="textarea" v-model="formData.desc" class="textarea"></el-input>

        <el-button type="primary" size="small" class="search">搜索</el-button>
      </el-form-item>

      <el-form-item>
        <el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%"
                  @selection-change="handleSelectionChange" class="tableList">
          <el-table-column type="selection" width="55"></el-table-column>
          <el-table-column label="账号" width="200" align="left">
            <template slot-scope="scope">{{ scope.row.usernameId }}</template>
          </el-table-column>
          <el-table-column prop="name" label="账号名称" width="200" align="center">
            <template slot-scope="scope">{{ scope.row.username }}</template>
          </el-table-column>
          <el-table-column prop="address" label="操作" width="200" align="right">
            <template slot-scope="scope">
              <el-button type="text" size="small">添加到白名单</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>

      <el-form-item>
        <el-input type="text" v-model="formData.search_value" placeholder="请输入账号ID搜索"
                  suffix-icon="el-input__icon el-icon-search" class="searchInput"></el-input>
      </el-form-item>

      <el-form-item>
        <el-table ref="multipleTable" :data="accountData" tooltip-effect="dark" style="width: 100%"
                  @selection-change="handleSelectionChange" class="tableList">
          <el-table-column type="selection" width="55"></el-table-column>
          <el-table-column label="账号名称" width="300" align="left">
            <template slot-scope="scope">{{ scope.row.username }}</template>
          </el-table-column>
          <el-table-column prop="address" label="操作" width="300" align="right">
            <template slot-scope="scope">
              <el-button type="text" size="small">移除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>

      <el-row>
        <el-col :span="24" style="border:1px solid #D8DCE6; margin: 50px 20px 20px 20px;"></el-col>
      </el-row>

      <el-col :span="24" style="padding: 10px 10px;">
        <h3>自定义设置</h3>
      </el-col>

      <el-form-item label="自定义设置：">
        <el-input type="textarea" v-model="formData.customSetting" class="textarea"></el-input>
      </el-form-item>

      <el-form-item>
        <el-button size="small" class="btn">取消</el-button>
        <el-button type="primary" @click="" size="small" class="btn">保存</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        fileList: [],

        formData: {
          type1: [],
          type2: [],
          resource: '',
          videoDuration: '1',
          videoVoice: '',
          skipDelayed: '1',
          pe: '',
          type: '',
          brand_value: '',
          Perf_value: '',
          Rem_value: '',
          setting: [],
          black_white: '',
          desc: '',
          search_value: '',
          customSetting: ''
        },

        multipleSelection: [],

        tableData: [
          {
            usernameId: '1723635dein',
            username: '1723635dein'
          }, {
            usernameId: '1723635dein',
            username: '1723635dein'
          }
        ],

        accountData: [
          {
            username: '1723635dein'
          },
          {
            username: '1723635dein'
          }
        ]

      }
    },
    watch: {},
    created() {
    },
    methods: {
      handleRemove(file, fileList) {
        console.log(file, fileList)
      },
      handlePreview(file) {
        console.log(file)
      },
      handleExceed(files, fileList) {
        this.$message.warning(`当前限制选择 3 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`)
      },
      beforeRemove(file, fileList) {
        return this.$confirm(`确定移除 ${file.name}？`)
      },
      handleSelectionChange(val) {
        this.multipleSelection = val
      }
    }
  }
</script>
<style scoped>
  h3 {
    color: #111111;
    margin-left: 30px;
  }

  .el-form-item {
    margin-bottom: 20px;
  }

  .text-f {
    font-size: 16px;
    color: #333333;
  }

  .videoInput {
    width: 202px;
  }

  .pe {
    width: 202px;
  }

  .download {
    position: absolute;
    left: 100px;
    top: 4px;
  }

  .textarea {
    width: 480px;
  }

  .search {
    position: absolute;
    margin-left: 20px;
    width: 100px;
  }

  .el-table {
    width: 600px;
  }

  .searchInput {
    margin-left: 450px;
    width: 200px;
  }

  .btn{
    width: 100px;
  }

  .el-table::before{
    width: 600px;
  }
</style>
