<template>
  <div class="app-container">
    <div class="filter-container">
      <div class="filter-add">
        <el-date-picker
          v-model="value1"
          type="daterange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期">
        </el-date-picker>

        <el-input v-model="userId" class="filter-input"></el-input>

        <el-button class="filter-item" type="primary">搜 索</el-button>
      </div>
    </div>
    <el-table
      v-loading="listLoading"
      :data="list"
      class="table"
      element-loading-text="加载中"
      style="margin-top: 20px;"
      highlight-current-row
    >
      <el-table-column align="left" prop="report_date" label="时间">
        <template slot-scope="scope">{{ scope.row.advertisingName }}</template>
      </el-table-column>
      <el-table-column align="center" prop="app_id" label="广告位ID">
        <template slot-scope="scope">{{ scope.row.advertisingId }}</template>
      </el-table-column>
      <el-table-column align="right" prop="os" label="状态">
        <template slot-scope="scope">{{ scope.row.setting }}</template>
      </el-table-column>
    </el-table>
    <pagination
      class="pagination"
      :total="total"
      :page.sync="queryFormat.pageNo"
      :limit.sync="queryFormat.pageSize"
      @pagination="fetchData"
    />
  </div>
</template>

<script>
  import Pagination from '@/components/Pagination'

  export default {
    components: { Pagination },
    data() {
      return {
        pagerCount: 5,
        queryFormat: {
          pageSize: 10,
          pageNo: 1,
          total: 0
        },
        listLoading: false,
        list: [{
          advertisingName: '时间',
          advertisingId: '操作者',
          setting: '操作'
        }],
        userId: '',
        total: 4,
        value1: ''
      }
    },
    created() {
    },
    methods: {
      handlePlacementFilter() {
      },
      fetchData() {
      },
      handleCreateApp() {
        this.$router.push({
          path: '/views/home/accountLIst'
        })
      }
    },
    computed: {}
  }
</script>
<style scoped lang="scss">
  .filter-container {
    overflow: hidden;
  }

  label {
    font-weight: 400;
  }

  .pagination {
    float: right;
    padding: 0;
    margin: 0;
  }

  .table {
    width: 100%;
    margin-top: 30px;
    margin-bottom: 30px;
  }

  .filter-item {
    width: 100px;
    height: 36px;
    margin-left: 15px;
  }

  .filter-input {
    width: 346px;
    margin-left: 15px;
  }
</style>
